import React, { useState, useEffect } from 'react';
import { Calendar } from './components/Calendar';
import { DailyEntryForm } from './components/DailyEntryForm';
import { MonthlyExpenses } from './components/MonthlyExpenses';
import { FinancialSummary } from './components/FinancialSummary';
import { DailyEntry, MonthlyExpense, FinancialSummary as FinancialSummaryType } from './types/types';

function App() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [entries, setEntries] = useState<DailyEntry[]>([]);
  const [monthlyExpenses, setMonthlyExpenses] = useState<MonthlyExpense>({
    rent: 0,
    electricity: 0,
    water: 0,
    milk: 0,
    other: 0
  });
  const [householdAllocation, setHouseholdAllocation] = useState(0);

  const calculateSummary = (): FinancialSummaryType => {
    const totalEarnings = entries.reduce((sum, entry) => sum + entry.earnings, 0);
    const totalProductCosts = entries.reduce((sum, entry) => sum + entry.productCosts, 0);
    const monthlyExpensesTotal = Object.values(monthlyExpenses).reduce((sum, value) => sum + value, 0);
    const temporaryProfit = totalEarnings - totalProductCosts - monthlyExpensesTotal;
    const finalSavings = temporaryProfit - householdAllocation;

    return {
      totalEarnings,
      totalProductCosts,
      monthlyExpenses: monthlyExpensesTotal,
      temporaryProfit,
      householdAllocation,
      finalSavings
    };
  };

  const handleSaveEntry = (entry: DailyEntry) => {
    const existingIndex = entries.findIndex(
      e => new Date(e.date).toDateString() === new Date(entry.date).toDateString()
    );

    if (existingIndex >= 0) {
      const newEntries = [...entries];
      newEntries[existingIndex] = entry;
      setEntries(newEntries);
    } else {
      setEntries([...entries, entry]);
    }
  };

  const existingEntry = entries.find(
    entry => new Date(entry.date).toDateString() === selectedDate.toDateString()
  );

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-800 mb-8">
          Fruit Shop Financial Manager
        </h1>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="space-y-6">
            <Calendar
              selectedDate={selectedDate}
              onDateChange={setSelectedDate}
              entries={entries}
            />
            <DailyEntryForm
              selectedDate={selectedDate}
              onSave={handleSaveEntry}
              existingEntry={existingEntry}
            />
          </div>

          <div>
            <MonthlyExpenses
              expenses={monthlyExpenses}
              onUpdate={setMonthlyExpenses}
            />
          </div>

          <div>
            <FinancialSummary
              summary={calculateSummary()}
              onHouseholdAllocationChange={setHouseholdAllocation}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;