export interface DailyEntry {
  date: string;
  earnings: number;
  productCosts: number;
  notes?: string;
}

export interface MonthlyExpense {
  rent: number;
  electricity: number;
  water: number;
  milk: number;
  other: number;
}

export interface FinancialSummary {
  totalEarnings: number;
  totalProductCosts: number;
  monthlyExpenses: number;
  temporaryProfit: number;
  householdAllocation: number;
  finalSavings: number;
}