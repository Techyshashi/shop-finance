import React from 'react';
import { Calendar as CalendarIcon } from 'lucide-react';
import { DailyEntry } from '../types/types';

interface CalendarProps {
  selectedDate: Date;
  onDateChange: (date: Date) => void;
  entries: DailyEntry[];
}

export function Calendar({ selectedDate, onDateChange, entries }: CalendarProps) {
  const daysInMonth = new Date(
    selectedDate.getFullYear(),
    selectedDate.getMonth() + 1,
    0
  ).getDate();

  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);

  return (
    <div className="bg-white rounded-lg shadow p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <CalendarIcon className="w-5 h-5" />
          {selectedDate.toLocaleString('default', { month: 'long', year: 'numeric' })}
        </h2>
        <div className="flex gap-2">
          <button
            onClick={() => onDateChange(new Date(selectedDate.setMonth(selectedDate.getMonth() - 1)))}
            className="p-2 hover:bg-gray-100 rounded"
          >
            ←
          </button>
          <button
            onClick={() => onDateChange(new Date(selectedDate.setMonth(selectedDate.getMonth() + 1)))}
            className="p-2 hover:bg-gray-100 rounded"
          >
            →
          </button>
        </div>
      </div>
      <div className="grid grid-cols-7 gap-1">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
          <div key={day} className="text-center font-medium text-sm py-2">
            {day}
          </div>
        ))}
        {days.map(day => {
          const date = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), day);
          const entry = entries.find(e => new Date(e.date).toDateString() === date.toDateString());
          
          return (
            <button
              key={day}
              onClick={() => onDateChange(date)}
              className={`p-2 text-sm rounded hover:bg-blue-50 ${
                date.toDateString() === selectedDate.toDateString() ? 'bg-blue-100' : ''
              } ${entry ? 'font-bold text-green-600' : ''}`}
            >
              {day}
            </button>
          );
        })}
      </div>
    </div>
  );
}