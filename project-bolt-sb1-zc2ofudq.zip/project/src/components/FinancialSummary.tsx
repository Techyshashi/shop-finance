import React from 'react';
import { DollarSign, PiggyBank, Home, Calculator } from 'lucide-react';
import { FinancialSummary as FinancialSummaryType } from '../types/types';

interface FinancialSummaryProps {
  summary: FinancialSummaryType;
  onHouseholdAllocationChange: (amount: number) => void;
}

export function FinancialSummary({ summary, onHouseholdAllocationChange }: FinancialSummaryProps) {
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
        <Calculator className="w-5 h-5" />
        Financial Summary
      </h3>
      
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="p-3 bg-green-50 rounded">
            <div className="text-sm text-green-600 flex items-center gap-2">
              <DollarSign className="w-4 h-4" />
              Total Earnings
            </div>
            <div className="text-lg font-bold text-green-700">
              ${summary.totalEarnings.toFixed(2)}
            </div>
          </div>
          
          <div className="p-3 bg-red-50 rounded">
            <div className="text-sm text-red-600">Product Costs</div>
            <div className="text-lg font-bold text-red-700">
              ${summary.totalProductCosts.toFixed(2)}
            </div>
          </div>
        </div>

        <div className="p-3 bg-orange-50 rounded">
          <div className="text-sm text-orange-600">Monthly Expenses</div>
          <div className="text-lg font-bold text-orange-700">
            ${summary.monthlyExpenses.toFixed(2)}
          </div>
        </div>

        <div className="p-3 bg-blue-50 rounded">
          <div className="text-sm text-blue-600 flex items-center gap-2">
            <Calculator className="w-4 h-4" />
            Temporary Profit
          </div>
          <div className="text-lg font-bold text-blue-700">
            ${summary.temporaryProfit.toFixed(2)}
          </div>
        </div>

        <div className="border-t pt-4">
          <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
            <Home className="w-4 h-4" />
            Household Allocation
          </label>
          <input
            type="number"
            value={summary.householdAllocation}
            onChange={(e) => onHouseholdAllocationChange(Number(e.target.value))}
            className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
            min="0"
            step="0.01"
          />
        </div>

        <div className="p-4 bg-green-100 rounded-lg">
          <div className="text-sm text-green-600 flex items-center gap-2 mb-1">
            <PiggyBank className="w-4 h-4" />
            Final Savings
          </div>
          <div className="text-2xl font-bold text-green-700">
            ${summary.finalSavings.toFixed(2)}
          </div>
        </div>
      </div>
    </div>
  );
}