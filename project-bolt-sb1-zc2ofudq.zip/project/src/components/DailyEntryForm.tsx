import React, { useState } from 'react';
import { DollarSign, ShoppingCart } from 'lucide-react';
import { DailyEntry } from '../types/types';

interface DailyEntryFormProps {
  selectedDate: Date;
  onSave: (entry: DailyEntry) => void;
  existingEntry?: DailyEntry;
}

export function DailyEntryForm({ selectedDate, onSave, existingEntry }: DailyEntryFormProps) {
  const [earnings, setEarnings] = useState(existingEntry?.earnings || 0);
  const [productCosts, setProductCosts] = useState(existingEntry?.productCosts || 0);
  const [notes, setNotes] = useState(existingEntry?.notes || '');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      date: selectedDate.toISOString(),
      earnings,
      productCosts,
      notes
    });
    if (!existingEntry) {
      setEarnings(0);
      setProductCosts(0);
      setNotes('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow p-4">
      <h3 className="text-lg font-semibold mb-4">
        {selectedDate.toLocaleDateString('default', { 
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        })}
      </h3>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4" />
              Daily Earnings
            </div>
          </label>
          <input
            type="number"
            value={earnings}
            onChange={(e) => setEarnings(Number(e.target.value))}
            className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
            min="0"
            step="0.01"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            <div className="flex items-center gap-2">
              <ShoppingCart className="w-4 h-4" />
              Product Costs
            </div>
          </label>
          <input
            type="number"
            value={productCosts}
            onChange={(e) => setProductCosts(Number(e.target.value))}
            className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
            min="0"
            step="0.01"
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Notes
          </label>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
            rows={3}
          />
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 px-4 rounded hover:bg-blue-700 transition-colors"
        >
          Save Entry
        </button>
      </div>
    </form>
  );
}