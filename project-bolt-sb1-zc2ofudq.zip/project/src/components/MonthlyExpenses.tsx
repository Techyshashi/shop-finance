import React from 'react';
import { Home, Zap, Droplets, Milk } from 'lucide-react';
import { MonthlyExpense } from '../types/types';

interface MonthlyExpensesProps {
  expenses: MonthlyExpense;
  onUpdate: (expenses: MonthlyExpense) => void;
}

export function MonthlyExpenses({ expenses, onUpdate }: MonthlyExpensesProps) {
  const handleChange = (key: keyof MonthlyExpense, value: number) => {
    onUpdate({ ...expenses, [key]: value });
  };

  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h3 className="text-lg font-semibold mb-4">Monthly Fixed Expenses</h3>
      
      <div className="space-y-4">
        <div>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-1">
            <Home className="w-4 h-4" /> Rent
          </label>
          <input
            type="number"
            value={expenses.rent}
            onChange={(e) => handleChange('rent', Number(e.target.value))}
            className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
            min="0"
            step="0.01"
          />
        </div>

        <div>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-1">
            <Zap className="w-4 h-4" /> Electricity
          </label>
          <input
            type="number"
            value={expenses.electricity}
            onChange={(e) => handleChange('electricity', Number(e.target.value))}
            className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
            min="0"
            step="0.01"
          />
        </div>

        <div>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-1">
            <Droplets className="w-4 h-4" /> Water
          </label>
          <input
            type="number"
            value={expenses.water}
            onChange={(e) => handleChange('water', Number(e.target.value))}
            className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
            min="0"
            step="0.01"
          />
        </div>

        <div>
          <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-1">
            <Milk className="w-4 h-4" /> Milk
          </label>
          <input
            type="number"
            value={expenses.milk}
            onChange={(e) => handleChange('milk', Number(e.target.value))}
            className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
            min="0"
            step="0.01"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Other Expenses
          </label>
          <input
            type="number"
            value={expenses.other}
            onChange={(e) => handleChange('other', Number(e.target.value))}
            className="w-full p-2 border rounded focus:ring-2 focus:ring-blue-500"
            min="0"
            step="0.01"
          />
        </div>
      </div>
    </div>
  );
}